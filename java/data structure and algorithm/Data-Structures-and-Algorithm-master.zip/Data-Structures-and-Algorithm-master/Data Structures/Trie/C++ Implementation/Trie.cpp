#include <bits/stdc++.h>
using namespace std;
class Trie {
    struct Node {
        map<char,Node> m;
        bool end=false;
    };
};
int main()
{

}
