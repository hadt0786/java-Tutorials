This repository will contain many important algorithms and data structures implemented in C,C++,Java and Python

