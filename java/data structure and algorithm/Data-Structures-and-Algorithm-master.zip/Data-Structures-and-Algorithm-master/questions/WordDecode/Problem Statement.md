#Div3 #FastestGeekFirst
#5 Zoozoobian Planet 

Subodh Chandra is a renowned scientist and he went to zoozobian planet to save the earth from their attack.But after reaching there, he was unable to understand any of their messages and chats.Luckily he got a dictionary which contains all the words used in Zoozoobian language.
As soon as Subodh Chanda found the dictionary, he sent all the words to earth along with their meanings. Unfortunately Subodh Chandra was caught by the barbaric Zoozoobian and before getting caught by Zoozobian, he also sent all the message to the people of earth.
Zoozoobian’s are very clever, they have added some random letters before and after the actual words in their conversation.No word is a prefix of another word in the dictionary and also no word is in contained in another word. For example, there are no words in the dictionary like “apple” and “pineapple “ because “apple” is contained in “pineapple”.
Consider another example, if their dictionary contains these words {“is”,”love”,”banana”,”apple”,”pizza” }
And their message is “zczzfafafafggggggggloveqrqrqrisqrqrpizzanonononottt”, then the actual sentence is “love is pizza“. 

Now your task is to save the earth by writing a program that would take the words in the dictionary and and a message by Zoozoobian which is encrypted by the zoozobian.Print the actual sentence from that encrypted message.
Input Format :
===================
First Line of Input contains all the words of the dictionary delimited or separated by blank space (" ").
Second line of input contains the encrypted message.

Output Format :
==============
Print the decrypted message 

Sample Input :
=============
in danger random tokio kolkata mumbai chennai
gafhagfhfdgsghfkolkatahsdjagshinyyyyqqywywydanger

Sample output:
==============
kolkata in danger

