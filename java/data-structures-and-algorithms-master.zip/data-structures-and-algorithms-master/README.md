# data-structures-and-algorithms
Codes and resolutions of the exercises of Goodrich, Tamassia &amp; Goldwasser's Data Structures &amp; Algorithms in Java Sixth Edition Book (2014).

## Status
[![Build Status](https://travis-ci.org/rogeriogentil/data-structures-and-algorithms.svg?branch=master)](https://travis-ci.org/rogeriogentil/data-structures-and-algorithms)
