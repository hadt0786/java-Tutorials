package rogeriogentil.data.structures.chapter05.reinforcement;

/**
 * Describe a way to use recursion to compute the sum of all the elements in an n × n (two-dimensional) array of integers.
* 
 * @author rogerio
 */
public class Exercise10 {

   
}
