package rogeriogentil.data.structures.chapter05.reinforcement;

/**
 *
 * @author rogerio
 */
public class Exercise08 {

   public static int toInt(String s) {
      char[] array = s.toCharArray();
      
      return 10498;
   }

   public static void main(String[] args) {
      String numero = "010498";
      Integer n = toInt(numero);
      System.out.println("n é inteiro? " + (n instanceof Integer));
   }
}
