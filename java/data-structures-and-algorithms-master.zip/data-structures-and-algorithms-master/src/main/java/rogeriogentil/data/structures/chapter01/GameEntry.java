package rogeriogentil.data.structures.chapter01;

/**
 *
 * @author rogerio
 */
public class GameEntry implements Cloneable {

   public int score;

   public GameEntry(int score) {
      this.score = score;
   }
   
}
