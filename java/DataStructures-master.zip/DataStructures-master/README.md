DataStructures
==============

Learning data structures through "Data Structures &amp; Algorithms" by Goodrich and Tomassia, 5th ed


Since I plan on doing random practice problems from the book, hopefully no one uses this to cheat. If they do, then the prof should have spent more time picking out questions. Please don't take it up with me.
