# Exercises
Working directories for exercises in book
##Chapter 3: Indices, Nodes, and Recursion
* P3-10Towers of Hanoi
##Chapter 4: Analysis Tools